# To-Do-App-in-React-code

This is a simple To Do Application in react. This is a fun project to do for beginners who are trying to learn and get their hands dirty on React. In this application, I've used React components, React forms, event handlers etc. It is a very easy quick application to do.

## Commands used to install Font awesome:

$ npm i --save @fortawesome/fontawesome-svg-core

$ npm i --save @fortawesome/free-solid-svg-icons

$ npm i --save @fortawesome/react-fontawesome

## Commands used to publish react files in github:

git remote set-url origin https://github.com/abarna1908/To-Do-App-in-React

npm run build

npm run deploy

## The published To-do App:
https://abarna1908.github.io/To-Do-App-in-React/
